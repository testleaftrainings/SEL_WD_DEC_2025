package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import utils.ReadValueFromExcel;

public class BaseClass {

	public ChromeDriver driver;

	// STEP 2 :1/14
	public static ExtentReports extent;

	// STEP 5 :1/14
	public static ExtentTest test;

	// testName, testDescription, testAuthor and testCategory
	// STEP 6 :1/14
	public String testName, testDescription, testAuthor, testCategory;

	// CI - Step 4
	public String fileName;

	@BeforeMethod
	public void precondition() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--guest");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		System.out.println("Value of driver " + driver);
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	// CI - Step 3
	@DataProvider(name = "getValue")
	public String[][] fetchData() throws IOException {
		return ReadValueFromExcel.getValue(fileName);

	}

	// STEP 1 :1/14
	@BeforeSuite
	public void startReport() {
		// Step1:
		ExtentHtmlReporter wb = new ExtentHtmlReporter("./ExtReport/loginReport.html");

		// Step2:
		extent = new ExtentReports();

		// Step3:
		extent.attachReporter(wb);
	}

	// STEP 3 :1/14
	@AfterSuite
	public void stopReport() {
		extent.flush();
	}

	// STEP 4 :1/14
	@BeforeClass
	public void testDetails() {
		test = extent.createTest("LoginPage", "LeafTaps");
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}

	// STEP 8 :1/14
	public void reportStep(String stepDetails, String status) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			// test.pass(MediaEntityBuilder.createScreenCaptureFromPath("./ReportSnap/image"+takeSnap()+".png").build());
			test.pass(stepDetails,
					MediaEntityBuilder.createScreenCaptureFromPath(".././ReportSnap/image" + takeSnap() + ".png").build());
		}
	}

	// STEP 10 :1/14
	public int takeSnap() throws IOException {
		// Create a random number
		int randomNumber = (int) (Math.random() * 999999 + 999999);
		File screenshotAs = driver.getScreenshotAs(OutputType.FILE);
		File target = new File("./ReportSnap/image" + randomNumber + ".png");
		FileUtils.copyFile(screenshotAs, target);
		return randomNumber;
	}

}
