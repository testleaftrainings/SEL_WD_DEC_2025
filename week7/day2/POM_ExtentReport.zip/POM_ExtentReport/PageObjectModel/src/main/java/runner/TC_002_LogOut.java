package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import base.BaseClass;
import pages.LoginPage;

public class TC_002_LogOut extends BaseClass {

	@Test(dataProvider = "getValue")
	public void TC_002_Logout(String uName, String pWord) throws IOException {
		LoginPage lp = new LoginPage(driver);
		lp.userName(uName).passWord(pWord).loginButton().clickLogOut();
	}

	@BeforeTest
	public void readData() {
		fileName = "LeafTapsLogin";
	}
}
