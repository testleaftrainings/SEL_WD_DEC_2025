package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public LoginPage userName(String uName) throws IOException {
		driver.findElement(By.id("username")).sendKeys(uName);
		reportStep("userName entered successfully", "pass"); 	// STEP 9 :1/14
		return this;
	}

	public LoginPage passWord(String pWord) throws IOException {
		driver.findElement(By.id("password")).sendKeys(pWord);
		reportStep("passWord entered successfully", "pass");
		return this;
	}

	public HomePage loginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);
	}
}
