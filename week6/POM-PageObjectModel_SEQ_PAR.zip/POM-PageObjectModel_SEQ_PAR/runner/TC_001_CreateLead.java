package runner;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass{
	
	@Test
	public void TC_001_CreateLeads() {
		
		LoginPage lp = new LoginPage(driver);
		lp.userName().passWord().loginButton()
		.clickCRMSFA().clickLeads().clickCreateLead();
	}
	
}
