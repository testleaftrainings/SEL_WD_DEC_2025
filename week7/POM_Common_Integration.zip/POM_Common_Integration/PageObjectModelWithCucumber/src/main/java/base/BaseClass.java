package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadValueFromExcel;

public class BaseClass extends AbstractTestNGCucumberTests{

	//ThreadLocal implementation
	public static final ThreadLocal<RemoteWebDriver> chDriver = new ThreadLocal<RemoteWebDriver>();
	
	public void setDriver() {
		chDriver.set(new ChromeDriver());
	}
	
	public RemoteWebDriver getDriver() {
		return chDriver.get();
	}
	
	
	// CI - Step 4
	public String fileName;

	@BeforeMethod
	public void precondition() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--guest");
		setDriver();
		getDriver().manage().window().maximize();
		System.out.println("Value of driver " + getDriver());
		getDriver().get("http://leaftaps.com/opentaps/");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		getDriver().close();
	}

	// CI - Step 3
	@DataProvider(name = "getValue")
	public String[][] fetchData() throws IOException {
		return ReadValueFromExcel.getValue(fileName);

	}

}
