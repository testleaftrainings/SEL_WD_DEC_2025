package base;

import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import utils.ReadValueFromExcel;

public class BaseClass {

	public ChromeDriver driver;

	// CI - Step 4
	public String fileName;

	@BeforeMethod
	public void precondition() {

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--guest");
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		System.out.println("Value of driver " + driver);
		driver.get("http://leaftaps.com/opentaps/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		driver.close();
	}

	// CI - Step 3
	@DataProvider(name = "getValue")
	public String[][] fetchData() throws IOException {
		return ReadValueFromExcel.getValue(fileName);

	}

}
