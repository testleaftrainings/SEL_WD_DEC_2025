package runner;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC_001_CreateLead extends BaseClass {
	
	// STEP 7 :1/14
	@BeforeTest
	public void setValues() {
		
		testName = "Login";
		testDescription = "Login with multiple credentials";
		testAuthor = "ANBU";
		testCategory = "Smoke";
		
	}

	@Test(dataProvider = "getValue")
	public void TC_001_CreateLeads(String uName, String pWord) throws IOException {

		LoginPage lp = new LoginPage(driver);
		lp.userName(uName).passWord(pWord).loginButton().clickCRMSFA().clickLeads().clickCreateLead();
	}
	
	@BeforeTest
	public void readData() {
		fileName = "LeafTapsLogin";
	}

}
