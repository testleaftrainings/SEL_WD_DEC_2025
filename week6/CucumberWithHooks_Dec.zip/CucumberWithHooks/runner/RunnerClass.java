package runner;

import base.BaseClass;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/main/java/feature/Login.feature", glue= {"stepDefenition"}, monochrome= true, publish= true, 
					tags= "not @Smoke")
public class RunnerClass extends BaseClass {

	
	//execution from RunnerClass
	//RunnerClass needs driver
	//driver is in HooksImplimentation
	//can we extends the HooksImplimentation in RunnerClass
	
	
	// the driver issue hasbeen resolved & glued hooks & stepDef
	
}
