package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class LoginPage extends BaseClass {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
	}

	public LoginPage userName(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
		return this;
	}

	public LoginPage passWord(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);
		return this;
	}

	public HomePage loginButton() {
		driver.findElement(By.className("decorativeSubmit")).click();
		return new HomePage(driver);
	}
}
