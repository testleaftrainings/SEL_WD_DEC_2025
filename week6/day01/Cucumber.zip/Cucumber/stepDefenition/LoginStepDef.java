package stepDefenition;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginStepDef {
	ChromeDriver driver;

	@Given("Launch the browser")
	public void launch_the_browser() {
		driver = new ChromeDriver();
	}

	@Given("Load the url")
	public void load_the_url() {
		driver.get("http://leaftaps.com/opentaps/");
	}

	@Given("Enter the userName {string}")
	public void enter_the_user_name(String uName) {
		driver.findElement(By.id("username")).sendKeys(uName);
	}

	@Given("Enter the passWord {string}")
	public void enter_the_pass_word(String pWord) {
		driver.findElement(By.id("password")).sendKeys(pWord);
	}

	@When("Click on the LoginButton")
	public void click_on_the_login_button() {
		driver.findElement(By.className("decorativeSubmit")).click();
	}

	@Then("Navigates to the Logout page")
	public void navigates_to_the_logout_page() {
		String title = driver.getTitle();
		System.out.println(title);
	}

	@When("Click on the LogoutButton")
	public void click_on_the_logout_button() {
		driver.findElement(By.id("logout")).click();
	}

}
